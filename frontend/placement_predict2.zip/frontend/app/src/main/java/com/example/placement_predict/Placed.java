package com.example.placement_predict;

public class Placed {
    public String Age;
    public String Gender;
    public String Stream;
    public String Internships;
    public String CGPA;

    public String Backlogs;
    public String CodingSkills;
    public String AptitudeSkills;
    public String TechnicalSkills;
    public String CommunicationSkills;

}
